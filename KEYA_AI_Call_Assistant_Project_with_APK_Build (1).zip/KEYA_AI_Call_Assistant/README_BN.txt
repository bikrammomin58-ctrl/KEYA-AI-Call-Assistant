KEYA AI CALL ASSISTANT — প্রাথমিক Android প্রজেক্ট

এই ZIP-এ Android Studio-তে খোলার মতো Kotlin project source আছে।
MP3 greeting ফাইলটি app/src/main/assets/greeting.mp3-এ রাখা হয়েছে।

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এই প্রথম সংস্করণ MP3-টি শুধু ফোনের স্পিকারে চালায়।
- Android-এর সাধারণ third-party app-কে SIM কলের অপর প্রান্তে সরাসরি audio পাঠানোর অনুমতি দেয় না।
- READ_PHONE_STATE অনুমতি পেলে incoming call state সম্পর্কে সীমিত notification দেখায়।
- নিজে থেকে কল রিসিভ করা, SIM call-এ greeting ঢোকানো, বা call recording এই starter-এ নেই।
- অন্য পক্ষকে জানিয়ে এবং সম্মতি নিয়ে যেকোনো রেকর্ডিং করতে হবে।

Build:
1. Android Studio-তে ZIP extract করে project folder খুলুন।
2. Gradle sync শেষ হতে দিন।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
4. ফোনে APK ইনস্টল করুন।

প্রস্তাবিত environment: Android Studio recent version, JDK 17, Android SDK 35।
