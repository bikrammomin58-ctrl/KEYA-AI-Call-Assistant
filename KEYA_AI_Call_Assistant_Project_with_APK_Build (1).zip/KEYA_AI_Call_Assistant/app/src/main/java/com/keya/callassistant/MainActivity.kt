package com.keya.callassistant

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.*
import android.app.Activity
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 42, 28, 28)
            setBackgroundColor(0xFFF4F6FB.toInt())
        }
        val title = TextView(this).apply {
            text = "KEYA AI"
            textSize = 30f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF183A70.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Personal Call Assistant"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 28)
        }
        status = TextView(this).apply {
            text = "অ্যাপ প্রস্তুত। MP3 শুনতে Play চাপুন।"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 24)
        }
        val play = Button(this).apply {
            text = "▶  Greeting Play"
            setOnClickListener { playGreeting() }
        }
        val stop = Button(this).apply {
            text = "■  Stop"
            setOnClickListener { stopGreeting() }
        }
        val permission = Button(this).apply {
            text = "কল স্টেট পারমিশন"
            setOnClickListener { requestPhonePermission() }
        }
        val note = TextView(this).apply {
            text = "নোট: এই ভার্সন MP3 ফোনের স্পিকারে চালায়। সাধারণ SIM কলে অপর প্রান্তে অডিও পাঠায় না এবং নিজে থেকে কল রিসিভ করে না।"
            textSize = 13f
            setTextColor(0xFF555555.toInt())
            setPadding(0, 28, 0, 0)
        }
        root.addView(title, match())
        root.addView(subtitle, match())
        root.addView(status, match())
        root.addView(play, match())
        root.addView(stop, match())
        root.addView(permission, match())
        root.addView(note, match())
        setContentView(root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED) requestPhonePermission()
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 10 }

    private fun requestPhonePermission() {
        ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.READ_PHONE_STATE), 101)
    }

    private fun playGreeting() {
        try {
            stopGreeting()
            player = MediaPlayer().apply {
                val afd = assets.openFd("greeting.mp3")
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setOnCompletionListener {
                    status.text = "অডিও শেষ হয়েছে।"
                    it.release()
                    player = null
                }
                prepare()
                start()
            }
            status.text = "বাংলা Greeting বাজছে..."
        } catch (e: Exception) {
            status.text = "অডিও চালানো যায়নি: ${e.localizedMessage}"
        }
    }

    private fun stopGreeting() {
        player?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        player = null
        status.text = "অডিও বন্ধ।"
    }

    override fun onDestroy() {
        stopGreeting()
        super.onDestroy()
    }
}
